import os
import json
import faiss
import numpy as np
from datetime import datetime
from sentence_transformers import SentenceTransformer

# =========================
# PATHS
# =========================
BASE_DIR = "memory"
CASES_PATH = os.path.join(BASE_DIR, "cases.json")
META_PATH = os.path.join(BASE_DIR, "metadata.json")
FAISS_PATH = os.path.join(BASE_DIR, "faiss.index")

# =========================
# EMBEDDING MODEL (STEP 2)
# =========================
embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
EMBED_DIM = 384  # fixed for MiniLM

# =========================
# INIT STORAGE FILES
# =========================
def init_storage():
    os.makedirs(BASE_DIR, exist_ok=True)

    if not os.path.exists(CASES_PATH):
        with open(CASES_PATH, "w") as f:
            json.dump({"cases": []}, f, indent=2)

    if not os.path.exists(META_PATH):
        with open(META_PATH, "w") as f:
            json.dump({"next_embedding_id": 0}, f, indent=2)

    if not os.path.exists(FAISS_PATH):
        index = faiss.IndexFlatIP(EMBED_DIM)  # cosine similarity
        faiss.write_index(index, FAISS_PATH)

# =========================
# LOAD HELPERS
# =========================
def load_cases():
    try:
        with open(CASES_PATH, "r") as f:
            data = json.load(f)
            if "cases" not in data:
                return {"cases": []}
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        return {"cases": []}


def save_cases(data):
    with open(CASES_PATH, "w") as f:
        json.dump(data, f, indent=2)

def load_meta():
    try:
        with open(META_PATH, "r") as f:
            data = json.load(f)
            if "next_embedding_id" not in data:
                return {"next_embedding_id": 0}
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        return {"next_embedding_id": 0}


def save_meta(data):
    with open(META_PATH, "w") as f:
        json.dump(data, f, indent=2)

def load_index():
    try:
        if os.path.exists(FAISS_PATH):
            index = faiss.read_index(FAISS_PATH)
            # sanity check
            if index.d != EMBED_DIM:
                raise ValueError("FAISS index dimension mismatch")
            return index
        else:
            raise FileNotFoundError
    except Exception:
        # recreate index safely
        index = faiss.IndexFlatIP(EMBED_DIM)
        faiss.write_index(index, FAISS_PATH)
        return index


def save_index(index):
    faiss.write_index(index, FAISS_PATH)

# =========================
# STEP 2: EMBEDDING
# =========================
def generate_embedding(text: str):
    emb = embedding_model.encode(text, normalize_embeddings=True)
    return np.array([emb], dtype="float32")

# =========================
# ADD NEW CASE TO MEMORY
# =========================
def add_case(summary_text, structured_summary):
    """
    Adds a new clinical case to memory
    """
    init_storage()

    cases_data = load_cases()
    meta = load_meta()
    index = load_index()

    embedding = generate_embedding(summary_text)

    embedding_id = meta["next_embedding_id"]
    case_id = f"CASE_{embedding_id:05d}"

    case_record = {
        "case_id": case_id,
        "summary_text": summary_text,
        "structured_summary": structured_summary,
        "created_at": datetime.now().isoformat(),
        "embedding_id": embedding_id
    }

    # Add to FAISS
    index.add(embedding)

    # Save everything
    cases_data["cases"].append(case_record)
    meta["next_embedding_id"] += 1

    save_cases(cases_data)
    save_meta(meta)
    save_index(index)

    return case_record

# =========================
# SEARCH SIMILAR CASES
# =========================
def search_similar(summary_text, top_k=1, threshold=0.60):
    """
    Returns similar past cases if found
    """
    if not os.path.exists(FAISS_PATH):
        return None

    index = load_index()
    cases_data = load_cases()["cases"]

    if index.ntotal == 0:
        return None

    query_emb = generate_embedding(summary_text)
    scores, indices = index.search(query_emb, top_k)

    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1 or score < threshold:
            continue

        matched_case = next(
            (c for c in cases_data if c["embedding_id"] == idx),
            None
        )

        if matched_case:
            results.append({
                "similarity": float(score),
                "case": matched_case
            })

    return results
