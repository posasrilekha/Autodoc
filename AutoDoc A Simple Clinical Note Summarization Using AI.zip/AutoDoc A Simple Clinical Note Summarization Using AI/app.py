import streamlit as st
import re
from transformers import T5Tokenizer, T5ForConditionalGeneration
from memory.faiss_memory import add_case, search_similar

# ------------------------
# Page configuration
# ------------------------
st.set_page_config(
    page_title="AutoDoc – Clinical Assistant",
    page_icon="🩺",
    layout="centered"
)

# ------------------------
# Load T5 summarizer (CPU)
# ------------------------
@st.cache_resource
def load_summarizer():
    tokenizer = T5Tokenizer.from_pretrained("t5-base")
    model = T5ForConditionalGeneration.from_pretrained("t5-base")
    model.eval()
    return tokenizer, model

tokenizer, model = load_summarizer()

# ------------------------
# Session state
# ------------------------
if "note" not in st.session_state:
    st.session_state.note = ""

if "structured" not in st.session_state:
    st.session_state.structured = None

if "similar_cases" not in st.session_state:
    st.session_state.similar_cases = []

# ------------------------
# Sidebar
# ------------------------
with st.sidebar:
    st.title("⚙️ System Info")
    st.markdown("**Model:** T5-Base")
    st.markdown("**Memory:** FAISS + Embeddings")
    st.info("No fine-tuning • CPU-only")

# ------------------------
# Title
# ------------------------
st.markdown(
    "<h1 style='text-align:center;'>🩺 AutoDoc – Clinical Assistant</h1>",
    unsafe_allow_html=True
)

# ------------------------
# SAMPLE NOTE
# ------------------------
SAMPLE_NOTE = (
    "A 58-year-old male presented to the emergency department with chest pain for three hours, "
    "described as pressure-like and radiating to the left shoulder. He also complained of nausea "
    "and sweating. Past medical history is significant for hypertension and smoking. "
    "He is currently taking amlodipine. ECG showed ST segment depression in the lateral leads. "
    "The patient was admitted for cardiac monitoring and started on aspirin and statins."
)

# ------------------------
# LEVEL-2 MEDICATION EXTRACTION
# ------------------------
def extract_medications(note_text: str):
    text = note_text.lower()

    patterns = [
        r"currently taking ([^.]+)",
        r"medications include ([^.]+)",
        r"started on ([^.]+)",
        r"on ([^.]+)"
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            meds_text = match.group(1)
            meds = re.split(r",|and", meds_text)
            meds = [
                m.strip().capitalize()
                for m in meds
                if len(m.strip()) > 2
            ]
            return ", ".join(meds[:2])

    return "Not documented"

# ------------------------
# STRUCTURED EXTRACTION
# ------------------------
def build_structured(note_text: str):
    text = note_text.lower()

    # Complaint
    if any(k in text for k in ["chest pain", "pressure-like", "radiating"]):
        complaint = "Chest pain"
    elif any(k in text for k in ["atrial fibrillation", "irregular heartbeat"]):
        complaint = "Atrial fibrillation"
    else:
        complaint = "Not documented"

    # Medication (dynamic)
    medication = extract_medications(note_text)

    # Plan
    if "admit" in text or "admitted" in text:
        plan = "Admitted for further management"
    elif "follow-up" in text:
        plan = "Discharged with advice for follow-up"
    else:
        plan = "Not documented"

    return {
        "Complaint": complaint,
        "History": "Not documented",
        "Medication": medication,
        "Plan": plan
    }

# ------------------------
# CALLBACKS
# ------------------------
def load_sample_note():
    st.session_state.note = SAMPLE_NOTE
    st.session_state.structured = None
    st.session_state.similar_cases = []

def analyze_note():
    with st.spinner("Analyzing clinical note..."):
        # ---- Summarization for FAISS
        prompt = (
            "summarize the following clinical note focusing on diagnosis, "
            "treatment, and clinical context: "
            + st.session_state.note
        )

        inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
        output_ids = model.generate(
            inputs["input_ids"],
            max_length=120,
            num_beams=2,
            length_penalty=1.1
        )

        summary_text = tokenizer.decode(
            output_ids[0],
            skip_special_tokens=True
        )

        # ---- Structured extraction from original note
        structured = build_structured(st.session_state.note)

        # ---- FAISS similarity search
        similar = search_similar(summary_text, threshold=0.60) or []

        # ---- Store current case
        add_case(summary_text, structured)

        st.session_state.structured = structured
        st.session_state.similar_cases = similar

# ------------------------
# INPUT
# ------------------------
st.text_area(
    "Paste Clinical Note Here:",
    key="note",
    height=170
)

col1, col2 = st.columns(2)

with col1:
    st.button("🧪 Load Sample Note", on_click=load_sample_note)

with col2:
    st.button(
        "🔍 Analyze",
        on_click=analyze_note,
        disabled=not st.session_state.note.strip()
    )

# ------------------------
# OUTPUT
# ------------------------
if st.session_state.structured:

    # ---- Similar past consultation
    if st.session_state.similar_cases:
        case = st.session_state.similar_cases[0]["case"]
        score = st.session_state.similar_cases[0]["similarity"]

        st.warning(
            f"🧠 Previously consulted with us for a similar condition "
            f"(similarity: {score:.2f})"
        )

        with st.expander("📂 View previous consultation"):
            st.json(case["structured_summary"])
    else:
        st.info("🧠 No similar past consultations found.")

    # ---- Current consultation
    st.success("✅ Clinical Summary Generated")
    st.markdown("### 🧾 Current Consultation")

    for label, emoji in [
        ("Complaint", "🩺"),
        ("History", "📜"),
        ("Medication", "💊"),
        ("Plan", "🧭")
    ]:
        value = st.session_state.structured[label]
        if value == "Not documented":
            st.markdown(f"**{emoji} {label}:** ⚠️ Not documented")
        else:
            st.markdown(f"**{emoji} {label}:** {value}")

    with st.expander("📄 Show raw JSON"):
        st.json(st.session_state.structured)
