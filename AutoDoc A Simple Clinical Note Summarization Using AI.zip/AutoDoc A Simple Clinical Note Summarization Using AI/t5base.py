import time
from transformers import T5Tokenizer, T5ForConditionalGeneration

start_load = time.time()

print("🔄 Loading T5-base model...")
tokenizer = T5Tokenizer.from_pretrained("t5-base")
model = T5ForConditionalGeneration.from_pretrained("t5-base")

print(f"✅ Model loaded in {time.time() - start_load:.2f} seconds\n")

note = (
    "summarize: A 65-year-old male presents with chest pain radiating to the left arm "
    "and shortness of breath for two days. Past medical history includes hypertension "
    "and type 2 diabetes mellitus. Patient is currently taking metformin and lisinopril. "
    "ECG shows mild ST depression. Plan to admit for cardiac monitoring and start aspirin."
)

start_infer = time.time()

inputs = tokenizer(note, return_tensors="pt", truncation=True)

summary_ids = model.generate(
    inputs["input_ids"],
    max_length=80,
    num_beams=2
)

summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)

print("🧾 Summary:")
print(summary)

print(f"\n⚡ Inference time: {time.time() - start_infer:.2f} seconds")
