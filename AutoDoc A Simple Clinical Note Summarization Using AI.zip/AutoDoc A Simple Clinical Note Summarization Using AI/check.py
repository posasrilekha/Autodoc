# ==============================
# AutoDoc – Library Version Checker
# ==============================

libraries = [
    "python",
    "tensorflow",
    "tf_keras",
    "keras",
    "numpy",
    "pandas",
    "matplotlib",
    "streamlit",
    "torch",
    "transformers",
    "faiss",
    "sklearn",
    "sentence_transformers",
    "groq"
]

print("\n🔍 Checking installed libraries:\n")

import sys

for lib in libraries:
    try:
        if lib == "python":
            print(f"{lib:<22} ✅ Installed (version: {sys.version.split()[0]})")
            continue

        module = __import__(lib)
        version = getattr(module, "__version__", "Unknown")
        print(f"{lib:<22} ✅ Installed (version: {version})")

    except ImportError:
        print(f"{lib:<22} ❌ Not installed")

print("\n✅ Environment check completed.")
